# GLSL 2D Scene. WIP

A Pen created on CodePen.io. Original URL: [https://codepen.io/darrylhuffman/pen/eYxJaRP](https://codepen.io/darrylhuffman/pen/eYxJaRP).

This is a second take on my previous pen whic was similar, but way too resource intensive for the CPU. So I re-made the way I render things, this time with the GPU. It's a work in progress! 

Still have a lot more coming with this pen. Goal is to make it scrollable.

You can see the previous pen here: https://codepen.io/darrylhuffman/pen/gOQyodd

Based on this Dribbble: https://dribbble.com/shots/20207096-Morning-Snack