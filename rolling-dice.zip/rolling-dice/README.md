# Rolling dice

A Pen created on CodePen.io. Original URL: [https://codepen.io/borntofrappe/pen/JjxXyyL](https://codepen.io/borntofrappe/pen/JjxXyyL).

Try your luck rolling a six sided dice.

---

Part of [_"Zdog Monday"_](https://codepen.io/collection/PYyrNq), a series devoted to simply enjoy pseudo-3D graphics produced with the [Zdog library](/https://zzz.dog/).