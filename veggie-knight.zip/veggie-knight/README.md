# Veggie Knight

A Pen created on CodePen.io. Original URL: [https://codepen.io/creativeocean/pen/poGWNNa](https://codepen.io/creativeocean/pen/poGWNNa).

I had a slow morning and felt like building something silly. (I built this on a Mac, so the emojis won't look right on PC)